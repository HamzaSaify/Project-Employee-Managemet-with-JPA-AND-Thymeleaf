package com.employee.EmployeeMangement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeMangementApplicationTests {

	@Test
	void contextLoads() {
	}

}
